<?php
class Trener3Kontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $this->hlavicka['titulek'] = 'trener3';
        $this->hlavicka['popis'] = 'Nabídka tréninků a trenérů';
        $this->hlavicka['klicova_slova'] = 'Nabídka, tréninky, trenéři';

        $this->pohled = 'trener3';
    }
}
<?php
class LoginModel {
    /**
     * Najde uživatele podle emailu a ověří heslo.
     *
     * @param string $email Email uživatele
     * @param string $heslo Heslo zadané uživatelem
     * @return bool Vrací TRUE, pokud se heslo shoduje, jinak FALSE.
     */
    public function najdiUzivatele(string $email, string $heslo): bool {
        $sql = "SELECT heslo FROM login WHERE email = ?";
        $vysledek = Db::dotazJeden($sql, [$email]);

        if ($vysledek && isset($vysledek['heslo'])) {
            // Ověření hesla pomocí password_verify
            if (password_verify($heslo, $vysledek['heslo'])) {
                return true;
            }
        }
        return false;
    }
}

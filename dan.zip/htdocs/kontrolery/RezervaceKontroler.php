<?php
class RezervaceKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $this->hlavicka['titulek'] = 'Rezervace';
        $this->hlavicka['popis'] = 'Rezervace tréninků';
        $this->hlavicka['klicova_slova'] = 'rezervace';

        $this->pohled = 'rezervace';
    }
}
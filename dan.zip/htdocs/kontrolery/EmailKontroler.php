<?php
class EmailKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $jmeno = $_POST['jmeno']; $predmet = $_POST['predmet']; $zprava = $_POST['zprava']; $email = $_POST['email'];
            
            $model = new EmailModel();

                $model->odesli("dan.rysavy2005@gmail.com", $predmet, $jmeno, $zprava, $email);
                $this->presmeruj("email");
        
        }
        $this->pohled = 'email';
    }
}
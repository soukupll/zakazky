<?php
require_once __DIR__ . '/../modely/UserModel.php';

class RegistraceKontroler extends Kontroler {
    private $model;

    public function __construct($model = null) {
        if ($model === null) {
            $model = new UserModel();
        }
        $this->model = $model;
    }

    public function zpracuj(array $parametry): void {
        $message = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $jmeno = trim($_POST['jmeno'] ?? '');
            $prijmeni = trim($_POST['prijmeni'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $heslo = $_POST['heslo'] ?? '';
            $hesloPotvrzeni = $_POST['heslo_potvrzeni'] ?? '';

            if (empty($jmeno) || empty($prijmeni) || empty($email) || empty($heslo)) {
                $message = "Všechna pole jsou povinná.";
            } elseif ($heslo !== $hesloPotvrzeni) {
                $message = "Hesla se neshodují.";
            } else {
                if ($this->model->createUser($jmeno, $prijmeni, $email, $heslo)) {
                    $message = "Registrace byla úspěšná!";
                } else {
                    $message = "Chyba při registraci.";
                }
            }
        }

        $this->hlavicka = [
            'titulek' => 'Registrace',
            'popis' => 'Registrujte se zde',
            'klicova_slova' => 'registrace, uživatel, registrace'
        ];

        $this->data['message'] = $message;
        include __DIR__ . '/../pohledy/registrace.phtml';
    }
}
?>

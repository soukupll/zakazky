<?php
class PrispevkyKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $spravcePrispevku = new PrispevkyModel();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST["id"])) {
                $id = $_POST["id"];

                if (isset($_POST["upravit"])) {
                    $prispevek = $spravcePrispevku->nactiPrispevek($id);
                    $_SESSION["nazevPrispevku"] = $prispevek['nazev'];
                    $_SESSION["textPrispevku"] = $prispevek['text'];
                    $_SESSION["id"] = $id;
                }

                if (isset($_POST["ulozit"])) {
                    $novyNazev = $_POST["upraveny_nazev"] ?? '';
                    $novyText = $_POST["upraveny_text"] ?? '';
                    $spravcePrispevku->aktualizujPrispevek($novyNazev, $novyText, $id);
                    unset($_SESSION["textPrispevku"], $_SESSION["nazevPrispevku"], $_SESSION["id"]);
                    $this->presmeruj("prispevky");
                }

                if (isset($_POST["smazat"])) {
                    $spravcePrispevku->smazPrispevek($id);
                    $this->presmeruj("prispevky");
                }
            }

            if (!empty($_POST['nazev']) && !empty($_POST['text'])) {
                $nazev = $_POST['nazev'];
                $text = $_POST['text'];
                $spravcePrispevku->ulozPrispevek($nazev, $text);
                $this->presmeruj('prispevky');
            }
        }

        $prispevky = $spravcePrispevku->VratClanky();
        $this->data['prispevky'] = $prispevky;
        $this->hlavicka['titulek'] = 'Příspěvky';
        $this->pohled = 'prispevky';
    }
}

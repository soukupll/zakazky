<?php
abstract class Kontroler
{
    protected array $data = array();
    protected string $pohled = "";
    protected array $hlavicka = array('titulek' => '', 'klicova_slova' => '', 'popis' => '');

    // Přidaný prázdný konstruktor pro kompatibilitu s voláním parent::__construct()
    public function __construct() {
        // Inicializace, pokud by byla potřeba v budoucnu
    }

    public function vypisPohled(): void
{
    if ($this->pohled) {
        extract($this->data);
        require __DIR__ . '/../pohledy/' . $this->pohled . ".phtml";
    }
}

    
    function JePrihlasen()
    {
        if (empty($_SESSION['uzivatel'])) {
            header('Location: /login');
            exit;
        }
    }
    
    public function presmeruj(string $url): never
    {
        header("Location: /$url");
        header("Connection: close");
        exit;
    }
    
    abstract function zpracuj(array $parametry): void;
}
?>

<?php

class ReservationKontroler extends Kontroler {

    public function zpracuj(array $parametry): void
    {
        // Pokud máme parametr 'ulozitTrenink' a odeslaný formulář
        if (isset($parametry[0]) && $parametry[0] === 'ulozitTrenink') {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_reservation'])) {

                // Načtení dat z formuláře
                $jmeno         = isset($_POST['jmeno']) ? trim($_POST['jmeno']) : '';
                $prijmeni      = isset($_POST['prijmeni']) ? trim($_POST['prijmeni']) : '';
                $datum         = isset($_POST['datum']) ? trim($_POST['datum']) : '';
                $cas           = isset($_POST['cas']) ? trim($_POST['cas']) : '';
                $typ_treninku  = isset($_POST['typ_treninku']) ? trim($_POST['typ_treninku']) : '';
                $trener        = isset($_POST['trener']) ? trim($_POST['trener']) : '';
                $poznamky      = isset($_POST['poznamky']) ? trim($_POST['poznamky']) : '';

                // Validace vstupních dat
                $errors = [];
                if (empty($jmeno)) {
                    $errors[] = 'Jméno je povinné.';
                }
                if (empty($prijmeni)) {
                    $errors[] = 'Příjmení je povinné.';
                }
                if (empty($datum)) {
                    $errors[] = 'Datum tréninku je povinné.';
                }
                if (empty($cas)) {
                    $errors[] = 'Čas tréninku je povinný.';
                }
                if (empty($typ_treninku)) {
                    $errors[] = 'Typ tréninku je povinný.';
                }
                if (empty($trener)) {
                    $errors[] = 'Trenér musí být vybrán.';
                }

                if (!empty($errors)) {
                    $this->pohled = 'rezervace';
                    $this->data = ['errors' => $errors];
                } else {
                    // Zpracování rezervace přes model
                    
                    $reservationModel = new ReservationModel();
                    $result = $reservationModel->createReservation($jmeno, $prijmeni, $datum, $cas, $typ_treninku, $trener, $poznamky);

                    if ($result) {
                        $this->presmeruj('rezervace');
                        $this->data = ['message' => 'Rezervace byla úspěšně uložena.'];
                    } else {
                        $this->pohled = 'rezervace';
                        $this->data = ['errors' => ['Došlo k chybě při ukládání rezervace.']];
                    }
                }
            }
        } elseif (isset($parametry[0]) && $parametry[0] === 'něco') {
            $this->pohled = 'rezervace';
            $this->data = ['info' => 'Detail rezervace...'];
        } else {
            $this->pohled = 'rezervace';
            $this->data = [];
        }
    }
}

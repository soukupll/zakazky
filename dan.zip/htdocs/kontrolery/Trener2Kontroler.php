<?php
class Trener2Kontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $this->hlavicka['titulek'] = 'trener2';
        $this->hlavicka['popis'] = 'Nabídka tréninků a trenérů';
        $this->hlavicka['klicova_slova'] = 'Nabídka, tréninky, trenéři';

        $this->pohled = 'trener2';
    }
}
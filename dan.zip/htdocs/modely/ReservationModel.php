<?php

class ReservationModel
{
    /**
     * Uloží rezervaci do databáze.
     *
     * @param string $jmeno Jméno uživatele
     * @param string $prijmeni Příjmení uživatele
     * @param string $datum Datum rezervace
     * @param string $cas Čas rezervace
     * @param string $typ_treninku Typ tréninku
     * @param string $trener Trenér
     * @param string $poznamky Volitelné poznámky
     * @return bool Vrací TRUE, pokud byla rezervace úspěšně uložena, jinak FALSE.
     */
    public function createReservation(string $jmeno, string $prijmeni, string $datum, string $cas, string $typ_treninku, string $trener, string $poznamky): bool
    {
        $sql = "INSERT INTO rezervace (jmeno, prijmeni, datum, cas, typ_treninku, trener, poznamky)
                VALUES (?,?,?,?,?,?,?)";
        $pocet = Db::dotaz($sql, [$jmeno, $prijmeni, $datum, $cas, $typ_treninku, $trener, $poznamky]);
        return $pocet > 0;
    }
}

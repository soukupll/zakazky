<?php
class LoginModel {
    public function najdiUzivatele(string $email, string $heslo): array|bool
    {
        return Db::dotazJeden('SELECT * FROM login WHERE email = ? AND heslo = ? LIMIT 1', [$email, $heslo]);
    }

}
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

class EmailModel
{
    public function odesli(string $komu, string $predmet, string $jmeno, string $zprava, string $od): bool
    {
        $mail = new PHPMailer(true);

            $mail->isSMTP();
            $mail->CharSet = "UTF-8";
            $mail->Host = 'smtp.gmail.com'; 
            $mail->SMTPAuth = true;
            $mail->Username = 'dan.rysavy2005@gmail.com'; 
            $mail->Password = 'tlho dpck tlfd oywv';     
            // https://myaccount.google.com/u/1/apppasswords?continue=https://myaccount.google.com/u/1/?utm_source%3DOGB%26utm_medium%3Dapp%26pageId%3Dnone&rapt=AEjHL4MllQ3gGcv-YwvdRNPC7BCQaCtQAobxg4ITyns-k85sj281tcoujCu-Pfy434rI6Ycgf1ikVvq8Z_b-_nbmJQ8e_jsK4qvLCN7_CHE7JAC6fXNEVS4      
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ),
            );
            

            // Nastavení odesílatele a příjemce
            $mail->setFrom($od, $jmeno);
            $mail->addAddress($komu); 

            // Obsah zprávy
            $mail->isHTML(true);
            $mail->Subject = $predmet;
            $mail->Body = $zprava;

            $mail->send();
            return true;
        
    }
}

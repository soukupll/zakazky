<?php
require_once 'Db.php';

class UserModel {
    public function createUser(string $jmeno, string $prijmeni, string $email, string $heslo): bool {
        // Zahashujeme heslo
        $hash = password_hash($heslo, PASSWORD_DEFAULT);

        // 1) Vložíme uživatele do tabulky uzivatele
        $sqlUzivatele = "INSERT INTO uzivatele (jmeno, prijmeni, email, heslo) VALUES (?, ?, ?, ?)";
        $vlozenoUzivatele = Db::dotaz($sqlUzivatele, [$jmeno, $prijmeni, $email, $hash]);

        // 2) Vložíme stejné přihlašovací údaje (email + heslo) do tabulky login
        $sqlLogin = "INSERT INTO login (email, heslo) VALUES (?, ?)";
        $vlozenoLogin = Db::dotaz($sqlLogin, [$email, $hash]);

        // Rezervace byla úspěšně vytvořena, pokud se povedly oba inserty
        return ($vlozenoUzivatele > 0 && $vlozenoLogin > 0);
    }
}
?>

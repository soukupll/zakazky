<?php
session_start();
function autoloadFunkce(string $trida): void
{
	// Končí název třídy řetězcem "Kontroler" ?
	if (preg_match('/Kontroler/', $trida))
		require("kontrolery/" . $trida . ".php");
	else
		require("modely/" . $trida . ".php");
}

// Registrace callbacku (Pod starým PHP 5.2 je nutné nahradit funkcí __autoload())
spl_autoload_register("autoloadFunkce");


Db::pripoj("localhost", "root", "", "gym");
// Vytvoření routeru a zpracování parametrů od uživatele z URL
$smerovac = new SmerovacKontroler();
$smerovac->zpracuj(array($_SERVER['REQUEST_URI']));

// Vyrenderování šablony
$smerovac->vypisPohled();

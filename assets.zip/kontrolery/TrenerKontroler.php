<?php

class TrenerKontroler extends Kontroler {

public function zpracuj(array $parametry): void {
    $reservationModel = new ReservationModel();

    // Blok pro smazání časového slotu
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($parametry[0]) && $parametry[0] === 'smazat') {
        $slotId = $_POST['slot_id'] ?? null;
        $trainerId = $_POST['trainer_id'] ?? null;
        if ($slotId) {
            $trenerModel = new TrenerModel();
            $trenerModel->deleteSlot($slotId);
        }
        $this->presmeruj("trener/detail/$trainerId");
        return;
    }


    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($parametry[0]) && $parametry[0] === 'upravit') {
        $slotId = $_POST['slot_id'] ?? null;
        $trainerId = $_POST['trainer_id'] ?? null;
        
        if ($slotId) {
            $trenerModel = new TrenerModel();
            $slot = $trenerModel->getSlot($slotId, $trainerId);
            $this->data['slot'] = $slot;
            $this->data['trainer'] = $reservationModel->getTrainerById($trainerId);
        }
        $this->pohled = "trener_edit_slot";
        return;
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($parametry[0]) && $parametry[0] === 'upravit-odeslat') {
        $slotId    = $_POST['slot_id'] ?? null;
        $trainerId = $_POST['trainer_id'] ?? null;
        $date      = $_POST['date'] ?? null;
        $timeSlot  = $_POST['time_slot'] ?? null;
        $isReserved= $_POST['is_reserved'] ?? null;

        if ($slotId && $trainerId && $date && $timeSlot && $isReserved !== null) {
            $trenerModel = new TrenerModel();
            $trenerModel->editSlot($slotId, $trainerId, $date, $timeSlot, $isReserved);
        }
        $this->presmeruj("trener/detail/$trainerId");
        return;
    }

    // Blok pro odeslání volného termínu (rezervace)
    if (isset($parametry[0]) && $parametry[0] === 'rezervace') {
        // Získáme data z POST
        $trainerId = (int)($_POST['trainer_id'] ?? 0);
        $datum = $_POST['datum'] ?? '';
        $time_slot = $_POST['time_slot'] ?? '';
        // Načteme detail trenéra pomocí metody z modelu
        $trainer = $reservationModel->getTrainerById($trainerId);
        // Předáme data do rezervace (prefill) – pouze trainer_name, datum a time_slot
        $this->data['prefill'] = [
            'trainer_name' => $trainer['name'] ?? '',
            'datum'        => $datum,
            'time_slot'    => $time_slot,
        ];
        $this->data['trainer'] = $trainer;
        $this->pohled = 'rezervace';
    }
    // Jinak pokud je první parametr "detail", zobraz detail trenéra
    elseif (isset($parametry[0]) && $parametry[0] === 'detail' && isset($parametry[1])) {
        $trainerId = (int)$parametry[1];
        $trainer = $reservationModel->getTrainerById($trainerId);
        $allSlots = $reservationModel->getAllFreeTimeSlots();
        $free_slots = array_filter($allSlots, function($slot) use ($trainerId) {
            return $slot['trainer_id'] == $trainerId;
        });
        $this->data['trainer'] = $trainer;
        $this->data['free_slots'] = $free_slots;
        $this->pohled = 'trener_detail';
    } else {
        // Výchozí - seznam trenérů
        $treneri = $reservationModel->getTrainers();
        $this->data['treneri'] = $treneri;
        $this->pohled = 'treneri';
    }
}
}

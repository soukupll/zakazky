<?php
/*
 * Kontroler pro zpracování chybové stránky
 */
class TestKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
		// Hlavička požadavku
		// Hlavička stránky
		$this->hlavicka['titulek'] = 'Chyba 404';
		// Nastavení šablony
		$this->pohled = 'test';
    }
}
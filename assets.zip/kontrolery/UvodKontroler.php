<?php

class UvodKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $this->hlavicka['titulek'] = 'Úvod';
        $this->hlavicka['popis'] = 'Vítejte na Koruna Gym';
        $this->hlavicka['klicova_slova'] = 'Vítejte, Koruna, Úvod';

        $this->pohled = 'uvod';
    }
}
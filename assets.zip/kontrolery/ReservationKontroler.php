<?php

class ReservationKontroler extends Kontroler {

    public function zpracuj(array $parametry): void
    {
        $reservationModel = new ReservationModel();

        // Načtení seznamu trenérů a všech volných slotů
        $treneri = $reservationModel->getTrainers();
        $this->data['treneri'] = $treneri;
        $this->data['all_slots'] = $reservationModel->getAllFreeTimeSlots();

        if (isset($parametry[0]) && $parametry[0] === 'ulozitTrenink') {
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_reservation'])) {

                // Načtení dat z formuláře
                $trainer_id = isset($_POST['trainer_id']) ? trim($_POST['trainer_id']) : '';
                $date = isset($_POST['datum']) ? trim($_POST['datum']) : '';
                $time_slot = isset($_POST['time_slot']) ? trim($_POST['time_slot']) : '';

                // Předpokládejme, že ID uživatele je uloženo v session
                $user_id = $_SESSION['user']['id'] ?? null;

                // Validace vstupních dat
                $errors = [];
                if (empty($trainer_id)) {
                    $errors[] = 'Trenér musí být vybrán.';
                }
                if (empty($date)) {
                    $errors[] = 'Datum tréninku je povinné.';
                }
                if (empty($time_slot)) {
                    $errors[] = 'Čas tréninku je povinný.';
                }
                if (empty($user_id)) {
                    $errors[] = 'Uživatel musí být přihlášen.';
                }

                if (!empty($errors)) {
                    $this->pohled = 'rezervace';
                    $this->data['errors'] = $errors;
                    $this->data['treneri'] = $treneri; // Předání trenérů zpět do pohledu
                    $this->data['casove_sloty'] = []; // Ujistěte se, že časové sloty jsou prázdné při chybě
                } else {
                    // Zpracování rezervace přes model
                    $result = $reservationModel->createReservation((int)$trainer_id, $date, $time_slot, (int)$user_id);

                    if ($result) {
                        $this->presmeruj('rezervace');
                        $this->data['message'] = 'Rezervace byla úspěšně uložena.';
                    } else {
                        $this->pohled = 'rezervace';
                        $this->data['errors'] = ['Došlo k chybě při ukládání rezervace.'];
                        $this->data['treneri'] = $treneri; // Předání trenérů zpět do pohledu
                        $this->data['casove_sloty'] = []; // Ujistěte se, že časové sloty jsou prázdné při chybě
                    }
                }
            }
        } else {
            $this->pohled = 'rezervace';
            $this->data['treneri'] = $treneri; // Předání trenérů do pohledu
        }
    }
}

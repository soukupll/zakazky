<?php

class NabidkaKontroler extends Kontroler
{
    public function zpracuj(array $parametry): void
    {
        $this->hlavicka['titulek'] = 'Nabídka';
        $this->hlavicka['popis'] = 'Nabídka tréninků a trenérů';
        $this->hlavicka['klicova_slova'] = 'Nabídka, tréninky, trenéři';

        $galerieModel = new GalerieModel();

        if (!empty($parametry[0])) {
            if ($parametry[0] === 'vlozit' && isset($_SESSION['uzivatel']) && $_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["file"])) {
                $cesta = "obrazky/" . basename($_FILES["file"]["name"]);
                $galerieModel->vlozObrazek($cesta);
                header("Location: /nabidka");
                exit;
            }

            if ($parametry[0] === 'smazat' && isset($_SESSION['uzivatel']) && $_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete'])) {
                $galerieModel->smazObrazek(intval($_POST['delete']));
                header("Location: /nabidka");
                exit;
            }
        }

        $this->data['obrazky'] = $galerieModel->nactiObrazky();
        $this->pohled = 'nabidka';
    }
}

    
    


    




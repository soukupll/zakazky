<?php
Class OdhlasitKontroler extends Kontroler
 {
    public function zpracuj(array $parametry): void
    {
            session_unset();
            session_destroy();
    }
 }
<?php
class LoginKontroler extends Kontroler {
	// Nová metoda zpracuj
	public function zpracuj(array $parametry): void {
		// Zpracovat POST žádost
		if ($_SERVER['REQUEST_METHOD'] === 'POST' && $parametry[0] === 'prihlas') {
			$email = $_POST['email'] ?? '';
			$heslo = $_POST['heslo'] ?? '';

			require_once __DIR__ . '/../modely/LoginModel.php';
			$loginModel = new LoginModel();
			$uzivatel = $loginModel->najdiUzivatele($email, $heslo);

			if ($uzivatel) {
				$_SESSION['uzivatel'] = $email; // může být upraveno dle potřeb
				$_SESSION['admin'] = $uzivatel['admin'];
				$this->presmeruj('uvod');
			} else {
				$this->data['message'] = 'Neplatné přihlašovací údaje.';
			}
		}
		$this->pohled = 'login'; // zobrazí se pohled login.phtml
	}
}

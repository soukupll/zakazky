<?php
class KalendarKontroler extends Kontroler
{
public function zpracuj(array $parametry): void
{
$this->hlavicka['titulek'] = 'Kalendář';
$this->hlavicka['popis'] = 'Kalendář na rezervaci tréninků';
$this->hlavicka['klicova_slova'] = 'kalendář';

$this->pohled = 'kalendar';
}
}
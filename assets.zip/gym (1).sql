-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2025 at 02:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `galerie`
--

CREATE TABLE `galerie` (
  `id` int(11) NOT NULL,
  `soubor` varchar(255) NOT NULL,
  `popis` text DEFAULT NULL,
  `datum_nahrani` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `galerie`
--

INSERT INTO `galerie` (`id`, `soubor`, `popis`, `datum_nahrani`) VALUES
(47, 'obrazky/3.webp', NULL, '2025-02-20 11:56:48'),
(48, 'obrazky/4.webp', NULL, '2025-02-20 11:56:54'),
(50, 'obrazky/7.webp', NULL, '2025-02-20 11:57:04'),
(51, 'obrazky/8.webp', NULL, '2025-02-20 11:57:09'),
(54, 'obrazky/10.webp', NULL, '2025-02-21 18:37:41'),
(55, 'obrazky/kruhacpico.webp', NULL, '2025-02-21 18:38:01'),
(56, 'obrazky/9.webp', NULL, '2025-02-21 18:38:12'),
(57, 'obrazky/10.webp', NULL, '2025-02-21 18:38:18'),
(58, 'obrazky/3.webp', NULL, '2025-02-23 19:39:20'),
(62, 'obrazky/14.webp', NULL, '2025-02-23 19:39:45'),
(63, 'obrazky/13.webp', NULL, '2025-02-23 19:40:13'),
(65, 'obrazky/kruhacpico2.webp', NULL, '2025-02-23 21:16:28');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `heslo` varchar(255) NOT NULL,
  `admin` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `heslo`, `admin`) VALUES
(4, 'rysavydaniel215@student.voskh.cz', '$2y$10$YTp3J4AHvbMeORAweyQCLO6JCXlYM3txj', 0),
(5, 'admin@admin.cz', '$2y$10$LvdCXQdeQkP73xlzwTV60uQmwwVI9Q7jUcvcYiNmFqyFNnjLsRZVq', 1);

-- --------------------------------------------------------

--
-- Table structure for table `prispevky`
--

CREATE TABLE `prispevky` (
  `id` int(11) NOT NULL,
  `text` varchar(150) NOT NULL,
  `nazev` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prispevky`
--

INSERT INTO `prispevky` (`id`, `text`, `nazev`) VALUES
(27, 'curasci', 'soutez v benchpresu');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time_slot` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `time_slots`
--

CREATE TABLE `time_slots` (
  `id` int(11) NOT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time_slot` varchar(255) DEFAULT NULL,
  `is_reserved` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `time_slots`
--

INSERT INTO `time_slots` (`id`, `trainer_id`, `date`, `time_slot`, `is_reserved`) VALUES
(4, 3, '2025-03-12', '16:00-17:02', 0),
(5, 1, '2025-03-01', '08:00-09:00', 0),
(6, 1, '2025-03-01', '09:00-10:00', 0),
(7, 2, '2025-03-01', '08:00-09:00', 0),
(8, 2, '2025-03-01', '09:00-10:00', 0),
(9, 3, '2025-03-01', '08:00-09:00', 0),
(10, 3, '2025-03-01', '09:00-10:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `specialization` mediumtext DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`id`, `name`, `specialization`, `contact_info`) VALUES
(1, 'ANETA HRADNICKÁ', '<section class=\"trainer__section\">\r\n  <h2 class=\"trainer__name\">ANETA HRADNICKÁ</h2>\r\n  <div class=\"trainer__content\">\r\n    <div class=\"trainer__image\">\r\n      <img src=\"obrazky/anet.webp\" alt=\"Jan Novák\" />\r\n    </div>\r\n    <div class=\"trainer__details\">\r\n      <h3>O trenérovi</h3>\r\n      <ul>\r\n        <li><strong>Věk:</strong> 21 let</li>\r\n        <li><strong>Specializace:</strong> Silový trénink</li>\r\n        <li><strong>Certifikace:</strong> Ať už je to nějaký relevantní certifikát</li>\r\n      </ul>\r\n      <p>\r\n      Jsem Anet, osobní trenérka v Koruna gym s více než 6 lety zkušeností ve fitness. Pomohu ti cítit se skvěle ve svém těle díky individuálnímu přístupu, udržitelnému cvičení a komplexnímu pohledu na pohyb i výživu.\r\n      </p>\r\n      <a href=\"obrazky/11.webp\" target=\"_blank\">\r\n        <button class=\"btn\">Zobrazit certifikát</button>\r\n      </a>\r\n    </div>\r\n  </div>\r\n</section>\r\n', 'anet.hr@koruna-gym.cz'),
(2, 'Natálie Novotná', '<section class=\"trainer__section\">\r\n  <h2 class=\"trainer__name\">Natálie Novotná</h2>\r\n  <div class=\"trainer__content\">\r\n    <div class=\"trainer__image\">\r\n      <img src=\"obrazky/namyslena.webp\" alt=\"Pavla Strejciusová\" />\r\n    </div>\r\n    <div class=\"trainer__details\">\r\n      <h3>O trenérovi</h3>\r\n      <ul>\r\n        <li><strong>Věk:</strong> 26 let</li>\r\n        <li><strong>Specializace:</strong>  Kardiotréning</li>\r\n        <li><strong>Certifikace:</strong> Ať už je to nějaký relevantní certifikát</li>\r\n      </ul>\r\n      <p>\r\n      Jsem Naty, fitness trenérka v Koruna Gym s vášní pro pohyb. Pomohu ti na cestě ke zdravějšímu a šťastnějšímu životu díky motivaci, znalostem a individuálnímu přístupu.\r\n      </p>\r\n      <a href=\"obrazky/aa.jpg\" target=\"_blank\">\r\n        <button class=\"btn\">Zobrazit certifikát</button>\r\n      </a>\r\n    </div>\r\n  </div>\r\n</section>', 'natalie.nov@koruna-gym.cz'),
(3, 'Arthur Buiko', '<section class=\"trainer__section\">\r\n  <h2 class=\"trainer__name\">Arthur Buiko</h2>\r\n  <div class=\"trainer__content\">\r\n    <div class=\"trainer__image\">\r\n      <img src=\"obrazky/procne.webp\" alt=\"Jan Novák\" />\r\n    </div>\r\n    <div class=\"trainer__details\">\r\n      <h3>O trenérovi</h3>\r\n      <ul>\r\n        <li><strong>Věk:</strong> 23 let</li>\r\n        <li><strong>Specializace:</strong> Silový trénink, Kardiotréning, Výživa</li>\r\n        <li><strong>Certifikace:</strong> Ať už je to nějaký relevantní certifikát</li>\r\n      </ul>\r\n      <p>\r\n      Jsem certifikovaný trenér a pomohu ti dosáhnout tvého cíle díky komplexnímu přístupu k tréninku i výživě. Společně uděláme rok 2024 co nejsportovnější! \r\n      </p>\r\n      <a href=\"obrazky/aa.jpg\" target=\"_blank\">\r\n        <button class=\"btn\">Zobrazit certifikát</button>\r\n      </a>\r\n    </div>\r\n  </div>\r\n</section>\r\n', 'arthur.buiko@koruna-gym.cz');

-- --------------------------------------------------------

--
-- Table structure for table `uzivatele`
--

CREATE TABLE `uzivatele` (
  `id` int(11) NOT NULL,
  `jmeno` varchar(100) NOT NULL,
  `prijmeni` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `heslo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `uzivatele`
--

INSERT INTO `uzivatele` (`id`, `jmeno`, `prijmeni`, `email`, `heslo`) VALUES
(5, 'daniel', 'rysavy', 'rysavydaniel215@student.voskh.cz', '$2y$10$YTp3J4AHvbMeORAweyQCLO6JCXlYM3txjDAfdl81YH4NZ/DlQrE3e'),
(6, 'Daniel', 'Rysavy', 'daniel@example.com', '$2y$10$abcdefghij1234567890'),
(8, 'admin', 'rysavy', 'admin@admin.cz', '$2y$10$LvdCXQdeQkP73xlzwTV60uQmwwVI9Q7jUcvcYiNmFqyFNnjLsRZVq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `galerie`
--
ALTER TABLE `galerie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prispevky`
--
ALTER TABLE `prispevky`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uzivatele`
--
ALTER TABLE `uzivatele`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `galerie`
--
ALTER TABLE `galerie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `prispevky`
--
ALTER TABLE `prispevky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `time_slots`
--
ALTER TABLE `time_slots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `uzivatele`
--
ALTER TABLE `uzivatele`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_slots`
--
ALTER TABLE `time_slots`
  ADD CONSTRAINT `time_slots_ibfk_1` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

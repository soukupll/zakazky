<?php

class PrispevkyModel
{
    public function ulozPrispevek($nazev, $text)
    {
        Db::dotazJeden("INSERT INTO prispevky (nazev, text) VALUES (?, ?)", [$nazev, $text]);
    }

    public function smazPrispevek($id)
    {
        Db::dotazJeden("DELETE FROM prispevky WHERE id=?", [$id]);
    }

    public function nactiPrispevek($id): array
    {
        $vysledek = Db::dotazJeden("SELECT nazev, text FROM prispevky WHERE id=?", [$id]);
        return [
            'nazev' => $vysledek['nazev'] ?? '',
            'text' => $vysledek['text'] ?? ''
        ];
    }

    public function aktualizujPrispevek($nazev, $text, $id): void
    {
        Db::dotazJeden("UPDATE prispevky SET nazev=?, text=? WHERE id=?", [$nazev, $text, $id]);
    }

    public function VratClanky(): array
    {
        return Db::dotazVsechny("SELECT id, nazev, text FROM prispevky ORDER BY id DESC");
    }
}

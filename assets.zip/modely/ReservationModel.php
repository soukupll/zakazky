<?php

class ReservationModel
{
    /**
     * Získání všech trenérů z databáze.
     *
     * @return array Pole trenérů.
     */
    public function getTrainers(): array
    {
        $sql = "SELECT id,  specialization,  name FROM trainers";
        return Db::dotazVsechny($sql);
    }

    /**
     * Získání trenéra podle ID.
     *
     * @param int $id ID trenéra.
     * @return array Pole s informacemi o trenérovi.
     */
    public function getTrainerById(int $id):array|bool {
        $sql = "SELECT id, name , specialization  , name FROM trainers WHERE id = ?";
        return Db::dotazJeden($sql, [$id]);
    }

    /**
     * Získání časových slotů pro dané datum a trenéra.
     *
     * @param string $date Datum.
     * @param int $trainer_id ID trenéra.
     * @return array Pole časových slotů.
     */
    public function getTimeSlots(string $date, int $trainer_id): array
    {
        $sql = "SELECT time_slot FROM time_slots WHERE date = ? AND trainer_id = ?";
        $slots = Db::dotazVsechny($sql, [$date, $trainer_id]);
        // Převod pole objektů na pole časových slotů
        $timeSlots = [];
        foreach ($slots as $slot) {
            $timeSlots[] = ['time_slot' => $slot['time_slot']];
        }
        return $timeSlots;
    }

    /**
     * Získá všechna volná časová okna.
     *
     * @return array Pole volných slotů s klíči trainer_id, date a time_slot.
     */
    public function getAllFreeTimeSlots(): array
    {
        $sql = "SELECT id, trainer_id, date, time_slot FROM time_slots WHERE is_reserved = 0";
        $data = Db::dotazVsechny($sql);
        error_log("getAllFreeTimeSlots: " . print_r($data, true)); // Debug log do PHP error logu
        return $data;
    }

    /**
     * Uložení rezervace do databáze.
     *
     * @param int $trainer_id ID trenéra.
     * @param string $date Datum rezervace.
     * @param string $time_slot Časový slot.
     * @param int $user_id ID uživatele.
     * @return bool True, pokud byla rezervace úspěšně uložena, jinak false.
     */
    public function createReservation(int $trainer_id, string $date, string $time_slot, int $user_id): bool
    {
        $sql = "INSERT INTO reservations (trainer_id, date, time_slot, user_id) VALUES (?, ?, ?, ?)";
        $pocet = Db::dotaz($sql, [$trainer_id, $date, $time_slot, $user_id]);
        return $pocet > 0;
    }
}

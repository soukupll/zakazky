<?php
require_once 'Db.php';
class LoginModel {
    public function najdiUzivatele(string $email, string $heslo): array|bool {
        $uzivatel = Db::dotazJeden('SELECT * FROM login WHERE email = ? LIMIT 1', [$email]);
        if ($uzivatel && isset($uzivatel['heslo']) && password_verify($heslo, $uzivatel['heslo'])) {
            return $uzivatel;
        }
        return false;
    }
}
?>
<?php
require_once 'Db.php';

class TrenerModel {
    public function getTrainerById($id): array|false {
        return Db::dotazJeden("SELECT id, specialization , name FROM treneri WHERE id = ?", [$id]);
    }

    // Nová metoda pro smazání časového slotu
    public function deleteSlot($slotId): int {
        return Db::dotaz("DELETE FROM time_slots WHERE id = ?", [$slotId]);
    }

    // Nová metoda pro úpravu časového slotu
    public function editSlot($slotId, $trainerId, $date, $timeSlot, $isReserved): int {
        return Db::dotaz("UPDATE time_slots SET trainer_id = ?, date = ?, time_slot = ?, is_reserved = ? WHERE id = ?", [$trainerId, $date, $timeSlot, $isReserved, $slotId]);
     }
     

     public function getSlot($slot_id, $trainer_id){
        $sql = "SELECT id, trainer_id, date, time_slot, is_reserved FROM time_slots WHERE id = ? AND trainer_id = ?";
        $slot = Db::dotazJeden($sql, [$slot_id, $trainer_id]);
        return $slot;
    }
    
    
    


}

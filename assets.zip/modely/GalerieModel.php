<?php

class GalerieModel
{
    public static function nactiObrazky(): array
    {
        return Db::dotazVsechny("SELECT * FROM galerie");
    }

    public static function vlozObrazek(string $cesta): void
    {
        Db::dotaz("INSERT INTO galerie (soubor) VALUES (?)", [$cesta]);
    }

    public static function smazObrazek(int $id): void
    {
        // Získání cesty k souboru
        $obrazek = Db::dotazJeden("SELECT soubor FROM galerie WHERE id = ?", [$id]);
        if ($obrazek && file_exists($obrazek['soubor'])) {
            unlink($obrazek['soubor']);
        }

        // Smazání záznamu z databáze
        Db::dotaz("DELETE FROM galerie WHERE id = ?", [$id]);
    }
}
